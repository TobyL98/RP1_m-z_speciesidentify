"""Initialising necessary modules in the
theoretical peptides package"""

