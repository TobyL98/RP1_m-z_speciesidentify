"""Species inference Package"""

__author__ = "Toby Lawrence"
__maintainer__ = "Toby Lawrence"
__version__ = "0.0.1"
__email__ = "tobylawrence@btinternet.com"

