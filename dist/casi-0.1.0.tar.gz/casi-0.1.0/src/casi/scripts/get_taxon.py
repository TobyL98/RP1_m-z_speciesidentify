"""
Gets the updated taxon information for Animalia from NCBI and saves it
as a taxon dump. This is used in thr fasta_seq_amenda1a2
to add extra taxonomic information
"""

from pathlib import Path

import pandas as pd
from ete4 import NCBITaxa

def get_all_taxaid():

    ncbi = NCBITaxa()

    # Download only once, reuse later
    #ncbi.update_taxonomy_database()
    # Get all taxa for chordata (TaxID: 7711)
    mammalia_taxaids = ncbi.get_descendant_taxa(40674, rank_limit="genus")
    print(f"Total animal taxa: {len(mammalia_taxaids)}")

    return mammalia_taxaids